﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarShowroom.Models
{
	[DisplayName("Position")]
	public class Position
	{
		public int PositionId { get; set; }

		[DisplayName("Title : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "The title must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string Title { get; set; }

		[DisplayName("Salary : ")]
		[Required(ErrorMessage = "Required field")]
		[DataType(DataType.Currency, ErrorMessage = "Value must be an amount")]
		[Range(1, 5000000, ErrorMessage = "The salary must be between 1 and 5,000,000")]
		public decimal Salary { get; set; }

		[DisplayName("Full-time : ")]
		public bool IsFullTime { get; set; }

		[DisplayName("Contract : ")]
		public bool IsContract { get; set; }

		public virtual ICollection<Worker> Workers { get; set; }
	}
}