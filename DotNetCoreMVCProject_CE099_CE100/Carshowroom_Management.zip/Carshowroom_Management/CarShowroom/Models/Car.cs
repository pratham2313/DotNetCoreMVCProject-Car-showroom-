﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarShowroom.Models
{
	[DisplayName("Car")]
	public class Car
	{
		public int CarId { get; set; }

		[DisplayName("Brand : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "The brand must be between 2 and 50 characters long")]
		public string Brand { get; set; }

		[DisplayName("Model : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Model musi mieć od 2 do 50 znaków")]
		public string Model { get; set; }

		[DisplayName("Price : ")]
		[Required(ErrorMessage = "Required field")]
		[DataType("₹", ErrorMessage = "Value must be an amount")]
		[Range(1, 50000000, ErrorMessage = "The price must be between 1,000 and 5,00,000,000,000")]
		public decimal Price { get; set; }

		[DisplayName("Quantity : ")]
		[Required(ErrorMessage = "Required field")]
        [Range(0, 100, ErrorMessage = "The price must be between 1,000 and 5,00,000,000,000")]
        public int quantity { get; set; }


        [DisplayName("New : ")]
		public bool IsNew { get; set; }

		public string BrandModel

		{
			get
			{
				if (quantity != 0)
				{
                    return string.Format("{0} {1} - Qua:{2}", Brand, Model, quantity);
                }
				return string.Empty;
			}
		}

        

        public virtual ICollection<Purchase> Purchases { get; set; }
	}
}