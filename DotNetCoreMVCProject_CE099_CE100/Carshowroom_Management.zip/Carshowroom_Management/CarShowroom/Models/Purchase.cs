﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarShowroom.Models
{
	
	[DisplayName("Sale")]
	public class Purchase
	{
		int count = 0;
		public int PurchaseId { get; set; }

		[DisplayName("Client : ")]
		[Required(ErrorMessage = "Wrong Formate")]
		public int ClientId { get; set; }

		[DisplayName("Employee : ")]
		[Required(ErrorMessage = "Wrong Formate")]
		public int WorkerId { get; set; }

		[DisplayName("Car : ")]
		[Required(ErrorMessage = "Wrong Formate")]
		public int CarId { get; set; }


        [DisplayName("Data")]
		[Required(ErrorMessage = "Required field")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyy}", ApplyFormatInEditMode = true)]
		[DataType(DataType.Date, ErrorMessage = "The value must be a date")]
		public DateTime TransactionDate { get; set; }

		public virtual Client Client { get; set; }

		public virtual Worker Worker { get; set; }

		public virtual Car Car { get; set; }
	}
}