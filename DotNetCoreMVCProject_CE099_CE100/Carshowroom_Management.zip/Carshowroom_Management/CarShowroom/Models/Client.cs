﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarShowroom.Models
{
	[DisplayName("Client")]
	public class Client
	{
		public int ClientId { get; set; }

		[DisplayName("Surname : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Surname must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string LastName { get; set; }

		[DisplayName("Name : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Imię musi mieć od 2 do 50 znaków")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string FirstName { get; set; }

		[DisplayName("Mobile-Num : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(10, MinimumLength = 10, ErrorMessage = "CNUM must be exactly 11 characters long")]
		public string Pesel { get; set; }

		[DisplayName("City : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(11, MinimumLength = 2, ErrorMessage = "The city must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string City { get; set; }

		[DisplayName("Street : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(11, MinimumLength = 2, ErrorMessage = "The street must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string Street { get; set; }

		[DisplayName("Street-Numer : ")]
		[Required(ErrorMessage = "Required field")]
		[Range(1, 10000, ErrorMessage = "The number must be between 1 and 10,000")]
		public int StreetNumber { get; set; }

		public string FullName
		{
			get
			{
				return string.Format("{0} {1}", FirstName, LastName);
			}
		}

		public virtual ICollection<Purchase> Purchases { get; set; }
	}
}