﻿using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CarShowroom.Models
{
	[DisplayName("Employee")]
	public class Worker
	{
		public int WorkerId { get; set; }

		[DisplayName("Surname : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Surname must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string LastName { get; set; }

		[DisplayName("Name : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(50, MinimumLength = 2, ErrorMessage = "Name must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string FirstName { get; set; }

		[DisplayName("CNUM")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(11, MinimumLength = 11, ErrorMessage = "CNUM must be exactly 11 characters long")]
		public string Pesel { get; set; }

		[DisplayName("City : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(11, MinimumLength = 2, ErrorMessage = "The city must be between 2 and 50 characters")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string City { get; set; }

		[DisplayName("Street : ")]
		[Required(ErrorMessage = "Required field")]
		[StringLength(11, MinimumLength = 2, ErrorMessage = "The street must be between 2 and 50 characters long")]
		[RegularExpression(@"^[A-ZĄĘŁŃÓŚŹŻ]{1}[a-ząćęłńóśźż]{1,49}$", ErrorMessage = "Wrong format")]
		public string Street { get; set; }

		[DisplayName("Street-Numer : ")]
		[Required(ErrorMessage = "Required field")]
		[Range(1, 10000, ErrorMessage = "The number must be between 1 and 10,000")]
		public int StreetNumber { get; set; }

		[DisplayName("Position : ")]
		[Required(ErrorMessage = "Required field")]
		public int PositionId { get; set; }

		public string FullName
		{
			get
			{
				return string.Format("{0} {1}", FirstName, LastName);
			}
		}

		public virtual Position Position { get; set; }

		public virtual ICollection<Purchase> Purchases { get; set; }
	}
}