﻿namespace CarShowroom.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class same : DbMigration
    {
        public override void Up()
        {
            DropColumn("Purchase", "carname");
        }
        
        public override void Down()
        {
        }
    }
}
