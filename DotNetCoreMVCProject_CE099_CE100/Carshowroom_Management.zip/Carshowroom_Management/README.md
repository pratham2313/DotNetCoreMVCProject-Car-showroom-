# CarShowroom
ASP.NET 5 + MS SQL CRUD, dedicated for car showroom management, created as a school assignment.

The application was inspired by Contoso University - ASP.NET tutorial project, available on MSDN.
